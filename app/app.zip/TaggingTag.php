<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TaggingTag extends Model
{
    protected $table = 'tagging_tags';

    public $timestamps = false;
}
